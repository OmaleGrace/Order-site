package handlers

import (
	"Order-site/email"
	"fmt"
	"net/http"
	"strconv"
)

func (h *Handlers) UpdateOrderStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	orderID, err := strconv.Atoi(r.FormValue("order_id"))
	if err != nil {
		http.Error(w, "Invalid order ID", http.StatusBadRequest)
		return
	}

	status := r.FormValue("status")

	validStatuses := map[string]bool{
		"pending":   true,
		"paid":      true,
		"preparing": true,
		"ready":     true,
		"completed": true,
		"cancelled": true,
	}

	if !validStatuses[status] {
		http.Error(w, "Invalid order status", http.StatusBadRequest)
		return
	}

	_, err = h.DB.Exec(`
	UPDATE orders
	SET status = $1
	WHERE id = $2
`, status, orderID)

	if err != nil {
		http.Error(w, "Could not update order", http.StatusInternalServerError)
		return
	}

	var userEmail string
	h.DB.QueryRow(`
	SELECT u.email FROM orders o
	JOIN users u ON u.id = o.user_id
	WHERE o.id = $1
`, orderID).Scan(&userEmail)

	if userEmail == "" {
		fmt.Println("Order status email skipped: no email found for order", orderID)
	} else {
		go func() {
			if err := email.Send(userEmail, "Order Update - Order #"+strconv.Itoa(orderID), fmt.Sprintf("<h1>Order status updated</h1><p>Your order #%d is now: <strong>%s</strong>.</p>", orderID, status)); err != nil {
				fmt.Println("Order status email error:", err)
			}
		}()
	}

	http.Redirect(w, r, "/admin/orders", http.StatusSeeOther)
}
